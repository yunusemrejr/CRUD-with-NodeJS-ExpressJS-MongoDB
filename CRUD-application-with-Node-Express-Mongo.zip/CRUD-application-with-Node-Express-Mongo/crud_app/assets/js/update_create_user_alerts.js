/*  changed my mind, not gonna use this JS file for alerts anymore  */
document.getElementById('homePgIDTag').style.backgroundColor="#ff662f";
 
 

